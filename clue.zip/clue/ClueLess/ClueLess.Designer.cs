﻿namespace ClueLess
{
    partial class ClueLess
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.HostIPText = new System.Windows.Forms.Label();
            this.IpAddr = new System.Windows.Forms.TextBox();
            this.JoinGameButton = new System.Windows.Forms.Button();
            this.HostGameButton = new System.Windows.Forms.Button();
            this.Study = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.ChatWindow = new System.Windows.Forms.TextBox();
            this.Hall = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.Lounge = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.Library = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.BilliardRoom = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.DiningRoom = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.Conservatory = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.Ballroom = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.Kitchen = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.PlayerChat = new System.Windows.Forms.TextBox();
            this.StartGameButton = new System.Windows.Forms.Button();
            this.EndGameButton = new System.Windows.Forms.Button();
            this.PeopleSelect = new System.Windows.Forms.ComboBox();
            this.Hallway0 = new System.Windows.Forms.Panel();
            this.Hallway10 = new System.Windows.Forms.Panel();
            this.Hallway8 = new System.Windows.Forms.Panel();
            this.Hallway9 = new System.Windows.Forms.Panel();
            this.Hallway11 = new System.Windows.Forms.Panel();
            this.Hallway1 = new System.Windows.Forms.Panel();
            this.Hallway2 = new System.Windows.Forms.Panel();
            this.Hallway5 = new System.Windows.Forms.Panel();
            this.Hallway6 = new System.Windows.Forms.Panel();
            this.Hallway3 = new System.Windows.Forms.Panel();
            this.Hallway7 = new System.Windows.Forms.Panel();
            this.Hallway4 = new System.Windows.Forms.Panel();
            this.MissScarlet = new System.Windows.Forms.Panel();
            this.ColMustard = new System.Windows.Forms.Panel();
            this.ProfPlum = new System.Windows.Forms.Panel();
            this.MrsPeacock = new System.Windows.Forms.Panel();
            this.MrGreen = new System.Windows.Forms.Panel();
            this.MrsWhite = new System.Windows.Forms.Panel();
            this.Study.SuspendLayout();
            this.Hall.SuspendLayout();
            this.Lounge.SuspendLayout();
            this.Library.SuspendLayout();
            this.BilliardRoom.SuspendLayout();
            this.DiningRoom.SuspendLayout();
            this.Conservatory.SuspendLayout();
            this.Ballroom.SuspendLayout();
            this.Kitchen.SuspendLayout();
            this.SuspendLayout();
            // 
            // HostIPText
            // 
            this.HostIPText.AutoSize = true;
            this.HostIPText.Location = new System.Drawing.Point(13, 12);
            this.HostIPText.Name = "HostIPText";
            this.HostIPText.Size = new System.Drawing.Size(42, 13);
            this.HostIPText.TabIndex = 0;
            this.HostIPText.Text = "Host IP";
            // 
            // IpAddr
            // 
            this.IpAddr.Location = new System.Drawing.Point(61, 9);
            this.IpAddr.Name = "IpAddr";
            this.IpAddr.Size = new System.Drawing.Size(111, 20);
            this.IpAddr.TabIndex = 1;
            // 
            // JoinGameButton
            // 
            this.JoinGameButton.Location = new System.Drawing.Point(16, 35);
            this.JoinGameButton.Name = "JoinGameButton";
            this.JoinGameButton.Size = new System.Drawing.Size(75, 23);
            this.JoinGameButton.TabIndex = 2;
            this.JoinGameButton.Text = "Join Game";
            this.JoinGameButton.UseVisualStyleBackColor = true;
            this.JoinGameButton.Click += new System.EventHandler(this.JoinGame_Click);
            // 
            // HostGameButton
            // 
            this.HostGameButton.Location = new System.Drawing.Point(97, 35);
            this.HostGameButton.Name = "HostGameButton";
            this.HostGameButton.Size = new System.Drawing.Size(75, 23);
            this.HostGameButton.TabIndex = 3;
            this.HostGameButton.Text = "Host Game";
            this.HostGameButton.UseVisualStyleBackColor = true;
            this.HostGameButton.Click += new System.EventHandler(this.HostGame_Click);
            // 
            // Study
            // 
            this.Study.BackColor = System.Drawing.Color.Silver;
            this.Study.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Study.Controls.Add(this.label1);
            this.Study.Location = new System.Drawing.Point(196, 118);
            this.Study.Name = "Study";
            this.Study.Size = new System.Drawing.Size(100, 100);
            this.Study.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Study";
            // 
            // ChatWindow
            // 
            this.ChatWindow.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ChatWindow.Location = new System.Drawing.Point(16, 752);
            this.ChatWindow.Multiline = true;
            this.ChatWindow.Name = "ChatWindow";
            this.ChatWindow.ReadOnly = true;
            this.ChatWindow.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ChatWindow.Size = new System.Drawing.Size(898, 116);
            this.ChatWindow.TabIndex = 5;
            // 
            // Hall
            // 
            this.Hall.BackColor = System.Drawing.Color.Silver;
            this.Hall.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hall.Controls.Add(this.label2);
            this.Hall.Location = new System.Drawing.Point(424, 118);
            this.Hall.Name = "Hall";
            this.Hall.Size = new System.Drawing.Size(100, 100);
            this.Hall.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Hall";
            // 
            // Lounge
            // 
            this.Lounge.BackColor = System.Drawing.Color.Silver;
            this.Lounge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Lounge.Controls.Add(this.label3);
            this.Lounge.Location = new System.Drawing.Point(652, 118);
            this.Lounge.Name = "Lounge";
            this.Lounge.Size = new System.Drawing.Size(100, 100);
            this.Lounge.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Lounge";
            // 
            // Library
            // 
            this.Library.BackColor = System.Drawing.Color.Silver;
            this.Library.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Library.Controls.Add(this.label4);
            this.Library.Location = new System.Drawing.Point(196, 346);
            this.Library.Name = "Library";
            this.Library.Size = new System.Drawing.Size(100, 100);
            this.Library.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(2, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Library";
            // 
            // BilliardRoom
            // 
            this.BilliardRoom.BackColor = System.Drawing.Color.Silver;
            this.BilliardRoom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BilliardRoom.Controls.Add(this.label5);
            this.BilliardRoom.Location = new System.Drawing.Point(424, 346);
            this.BilliardRoom.Name = "BilliardRoom";
            this.BilliardRoom.Size = new System.Drawing.Size(100, 100);
            this.BilliardRoom.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(2, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Billiard Room";
            // 
            // DiningRoom
            // 
            this.DiningRoom.BackColor = System.Drawing.Color.Silver;
            this.DiningRoom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DiningRoom.Controls.Add(this.label6);
            this.DiningRoom.Location = new System.Drawing.Point(652, 346);
            this.DiningRoom.Name = "DiningRoom";
            this.DiningRoom.Size = new System.Drawing.Size(100, 100);
            this.DiningRoom.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(2, 2);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Dining Room";
            // 
            // Conservatory
            // 
            this.Conservatory.BackColor = System.Drawing.Color.Silver;
            this.Conservatory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Conservatory.Controls.Add(this.label7);
            this.Conservatory.Location = new System.Drawing.Point(196, 574);
            this.Conservatory.Name = "Conservatory";
            this.Conservatory.Size = new System.Drawing.Size(100, 100);
            this.Conservatory.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(2, 2);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Conservatory";
            // 
            // Ballroom
            // 
            this.Ballroom.BackColor = System.Drawing.Color.Silver;
            this.Ballroom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Ballroom.Controls.Add(this.label8);
            this.Ballroom.Location = new System.Drawing.Point(424, 574);
            this.Ballroom.Name = "Ballroom";
            this.Ballroom.Size = new System.Drawing.Size(100, 100);
            this.Ballroom.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(2, 2);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Ballroom";
            // 
            // Kitchen
            // 
            this.Kitchen.BackColor = System.Drawing.Color.Silver;
            this.Kitchen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Kitchen.Controls.Add(this.label9);
            this.Kitchen.Location = new System.Drawing.Point(652, 574);
            this.Kitchen.Name = "Kitchen";
            this.Kitchen.Size = new System.Drawing.Size(100, 100);
            this.Kitchen.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(2, 2);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Kitchen";
            // 
            // PlayerChat
            // 
            this.PlayerChat.Location = new System.Drawing.Point(16, 726);
            this.PlayerChat.MaxLength = 100;
            this.PlayerChat.Name = "PlayerChat";
            this.PlayerChat.Size = new System.Drawing.Size(901, 20);
            this.PlayerChat.TabIndex = 6;
            this.PlayerChat.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PlayerChat_KeyDown);
            // 
            // StartGameButton
            // 
            this.StartGameButton.Enabled = false;
            this.StartGameButton.Location = new System.Drawing.Point(179, 35);
            this.StartGameButton.Name = "StartGameButton";
            this.StartGameButton.Size = new System.Drawing.Size(75, 23);
            this.StartGameButton.TabIndex = 7;
            this.StartGameButton.Text = "Start Game";
            this.StartGameButton.UseVisualStyleBackColor = true;
            this.StartGameButton.Click += new System.EventHandler(this.StartGameButton_Click);
            // 
            // EndGameButton
            // 
            this.EndGameButton.Location = new System.Drawing.Point(98, 35);
            this.EndGameButton.Name = "EndGameButton";
            this.EndGameButton.Size = new System.Drawing.Size(75, 23);
            this.EndGameButton.TabIndex = 8;
            this.EndGameButton.Text = "End Game";
            this.EndGameButton.UseVisualStyleBackColor = true;
            this.EndGameButton.Visible = false;
            // 
            // PeopleSelect
            // 
            this.PeopleSelect.FormattingEnabled = true;
            this.PeopleSelect.Items.AddRange(new object[] {
            "Miss Scarlet",
            "Professor Plum",
            "Colonel Mustard",
            "Mrs. Peacock",
            "Mr. Green",
            "Mrs. White"});
            this.PeopleSelect.Location = new System.Drawing.Point(16, 64);
            this.PeopleSelect.Name = "PeopleSelect";
            this.PeopleSelect.Size = new System.Drawing.Size(121, 21);
            this.PeopleSelect.TabIndex = 9;
            this.PeopleSelect.Text = "Miss Scarlet";
            // 
            // Hallway0
            // 
            this.Hallway0.BackColor = System.Drawing.Color.Silver;
            this.Hallway0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hallway0.Location = new System.Drawing.Point(295, 149);
            this.Hallway0.Name = "Hallway0";
            this.Hallway0.Size = new System.Drawing.Size(130, 38);
            this.Hallway0.TabIndex = 5;
            // 
            // Hallway10
            // 
            this.Hallway10.BackColor = System.Drawing.Color.Silver;
            this.Hallway10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hallway10.Location = new System.Drawing.Point(295, 379);
            this.Hallway10.Name = "Hallway10";
            this.Hallway10.Size = new System.Drawing.Size(130, 38);
            this.Hallway10.TabIndex = 6;
            // 
            // Hallway8
            // 
            this.Hallway8.BackColor = System.Drawing.Color.Silver;
            this.Hallway8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hallway8.Location = new System.Drawing.Point(295, 608);
            this.Hallway8.Name = "Hallway8";
            this.Hallway8.Size = new System.Drawing.Size(130, 38);
            this.Hallway8.TabIndex = 6;
            // 
            // Hallway9
            // 
            this.Hallway9.BackColor = System.Drawing.Color.Silver;
            this.Hallway9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hallway9.Location = new System.Drawing.Point(523, 608);
            this.Hallway9.Name = "Hallway9";
            this.Hallway9.Size = new System.Drawing.Size(130, 38);
            this.Hallway9.TabIndex = 9;
            // 
            // Hallway11
            // 
            this.Hallway11.BackColor = System.Drawing.Color.Silver;
            this.Hallway11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hallway11.Location = new System.Drawing.Point(523, 379);
            this.Hallway11.Name = "Hallway11";
            this.Hallway11.Size = new System.Drawing.Size(130, 38);
            this.Hallway11.TabIndex = 8;
            // 
            // Hallway1
            // 
            this.Hallway1.BackColor = System.Drawing.Color.Silver;
            this.Hallway1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hallway1.Location = new System.Drawing.Point(523, 149);
            this.Hallway1.Name = "Hallway1";
            this.Hallway1.Size = new System.Drawing.Size(130, 38);
            this.Hallway1.TabIndex = 7;
            // 
            // Hallway2
            // 
            this.Hallway2.BackColor = System.Drawing.Color.Silver;
            this.Hallway2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hallway2.Location = new System.Drawing.Point(226, 217);
            this.Hallway2.Name = "Hallway2";
            this.Hallway2.Size = new System.Drawing.Size(38, 130);
            this.Hallway2.TabIndex = 6;
            // 
            // Hallway5
            // 
            this.Hallway5.BackColor = System.Drawing.Color.Silver;
            this.Hallway5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hallway5.Location = new System.Drawing.Point(226, 445);
            this.Hallway5.Name = "Hallway5";
            this.Hallway5.Size = new System.Drawing.Size(38, 130);
            this.Hallway5.TabIndex = 7;
            // 
            // Hallway6
            // 
            this.Hallway6.BackColor = System.Drawing.Color.Silver;
            this.Hallway6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hallway6.Location = new System.Drawing.Point(455, 445);
            this.Hallway6.Name = "Hallway6";
            this.Hallway6.Size = new System.Drawing.Size(38, 130);
            this.Hallway6.TabIndex = 9;
            // 
            // Hallway3
            // 
            this.Hallway3.BackColor = System.Drawing.Color.Silver;
            this.Hallway3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hallway3.Location = new System.Drawing.Point(455, 217);
            this.Hallway3.Name = "Hallway3";
            this.Hallway3.Size = new System.Drawing.Size(38, 130);
            this.Hallway3.TabIndex = 8;
            // 
            // Hallway7
            // 
            this.Hallway7.BackColor = System.Drawing.Color.Silver;
            this.Hallway7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hallway7.Location = new System.Drawing.Point(683, 445);
            this.Hallway7.Name = "Hallway7";
            this.Hallway7.Size = new System.Drawing.Size(38, 130);
            this.Hallway7.TabIndex = 11;
            // 
            // Hallway4
            // 
            this.Hallway4.BackColor = System.Drawing.Color.Silver;
            this.Hallway4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Hallway4.Location = new System.Drawing.Point(683, 217);
            this.Hallway4.Name = "Hallway4";
            this.Hallway4.Size = new System.Drawing.Size(38, 130);
            this.Hallway4.TabIndex = 10;
            // 
            // MissScarlet
            // 
            this.MissScarlet.BackColor = System.Drawing.Color.Red;
            this.MissScarlet.Location = new System.Drawing.Point(295, 12);
            this.MissScarlet.Name = "MissScarlet";
            this.MissScarlet.Size = new System.Drawing.Size(17, 17);
            this.MissScarlet.TabIndex = 12;
            this.MissScarlet.Visible = false;
            // 
            // ColMustard
            // 
            this.ColMustard.BackColor = System.Drawing.Color.Yellow;
            this.ColMustard.Location = new System.Drawing.Point(341, 12);
            this.ColMustard.Name = "ColMustard";
            this.ColMustard.Size = new System.Drawing.Size(17, 17);
            this.ColMustard.TabIndex = 13;
            this.ColMustard.Visible = false;
            // 
            // ProfPlum
            // 
            this.ProfPlum.BackColor = System.Drawing.Color.Fuchsia;
            this.ProfPlum.Location = new System.Drawing.Point(318, 12);
            this.ProfPlum.Name = "ProfPlum";
            this.ProfPlum.Size = new System.Drawing.Size(17, 17);
            this.ProfPlum.TabIndex = 13;
            this.ProfPlum.Visible = false;
            // 
            // MrsPeacock
            // 
            this.MrsPeacock.BackColor = System.Drawing.Color.Blue;
            this.MrsPeacock.Location = new System.Drawing.Point(364, 12);
            this.MrsPeacock.Name = "MrsPeacock";
            this.MrsPeacock.Size = new System.Drawing.Size(17, 17);
            this.MrsPeacock.TabIndex = 14;
            this.MrsPeacock.Visible = false;
            // 
            // MrGreen
            // 
            this.MrGreen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.MrGreen.Location = new System.Drawing.Point(387, 12);
            this.MrGreen.Name = "MrGreen";
            this.MrGreen.Size = new System.Drawing.Size(17, 17);
            this.MrGreen.TabIndex = 15;
            this.MrGreen.Visible = false;
            // 
            // MrsWhite
            // 
            this.MrsWhite.BackColor = System.Drawing.Color.White;
            this.MrsWhite.Location = new System.Drawing.Point(408, 12);
            this.MrsWhite.Name = "MrsWhite";
            this.MrsWhite.Size = new System.Drawing.Size(17, 17);
            this.MrsWhite.TabIndex = 16;
            this.MrsWhite.Visible = false;
            // 
            // ClueLess
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(929, 878);
            this.Controls.Add(this.MrsWhite);
            this.Controls.Add(this.MrGreen);
            this.Controls.Add(this.MrsPeacock);
            this.Controls.Add(this.ProfPlum);
            this.Controls.Add(this.ColMustard);
            this.Controls.Add(this.MissScarlet);
            this.Controls.Add(this.Hallway7);
            this.Controls.Add(this.Hallway4);
            this.Controls.Add(this.Hallway6);
            this.Controls.Add(this.Hallway5);
            this.Controls.Add(this.Hallway3);
            this.Controls.Add(this.Hallway2);
            this.Controls.Add(this.Hallway9);
            this.Controls.Add(this.Hallway8);
            this.Controls.Add(this.Hallway11);
            this.Controls.Add(this.Hallway1);
            this.Controls.Add(this.Hallway10);
            this.Controls.Add(this.Hallway0);
            this.Controls.Add(this.PeopleSelect);
            this.Controls.Add(this.StartGameButton);
            this.Controls.Add(this.PlayerChat);
            this.Controls.Add(this.Kitchen);
            this.Controls.Add(this.Ballroom);
            this.Controls.Add(this.Conservatory);
            this.Controls.Add(this.DiningRoom);
            this.Controls.Add(this.BilliardRoom);
            this.Controls.Add(this.Library);
            this.Controls.Add(this.Lounge);
            this.Controls.Add(this.Hall);
            this.Controls.Add(this.ChatWindow);
            this.Controls.Add(this.Study);
            this.Controls.Add(this.HostGameButton);
            this.Controls.Add(this.JoinGameButton);
            this.Controls.Add(this.IpAddr);
            this.Controls.Add(this.HostIPText);
            this.Controls.Add(this.EndGameButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ClueLess";
            this.Text = "ClueLess";
            this.Study.ResumeLayout(false);
            this.Study.PerformLayout();
            this.Hall.ResumeLayout(false);
            this.Hall.PerformLayout();
            this.Lounge.ResumeLayout(false);
            this.Lounge.PerformLayout();
            this.Library.ResumeLayout(false);
            this.Library.PerformLayout();
            this.BilliardRoom.ResumeLayout(false);
            this.BilliardRoom.PerformLayout();
            this.DiningRoom.ResumeLayout(false);
            this.DiningRoom.PerformLayout();
            this.Conservatory.ResumeLayout(false);
            this.Conservatory.PerformLayout();
            this.Ballroom.ResumeLayout(false);
            this.Ballroom.PerformLayout();
            this.Kitchen.ResumeLayout(false);
            this.Kitchen.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label HostIPText;
        private System.Windows.Forms.TextBox IpAddr;
        private System.Windows.Forms.Button JoinGameButton;
        private System.Windows.Forms.Button HostGameButton;
        private System.Windows.Forms.Panel Study;
        private System.Windows.Forms.TextBox ChatWindow;
        private System.Windows.Forms.Panel Hall;
        private System.Windows.Forms.Panel Lounge;
        private System.Windows.Forms.Panel Library;
        private System.Windows.Forms.Panel BilliardRoom;
        private System.Windows.Forms.Panel DiningRoom;
        private System.Windows.Forms.Panel Conservatory;
        private System.Windows.Forms.Panel Ballroom;
        private System.Windows.Forms.Panel Kitchen;
        private System.Windows.Forms.TextBox PlayerChat;
        private System.Windows.Forms.Button StartGameButton;
        private System.Windows.Forms.Button EndGameButton;
        private System.Windows.Forms.ComboBox PeopleSelect;
        private System.Windows.Forms.Panel Hallway0;
        private System.Windows.Forms.Panel Hallway10;
        private System.Windows.Forms.Panel Hallway8;
        private System.Windows.Forms.Panel Hallway9;
        private System.Windows.Forms.Panel Hallway11;
        private System.Windows.Forms.Panel Hallway1;
        private System.Windows.Forms.Panel Hallway2;
        private System.Windows.Forms.Panel Hallway5;
        private System.Windows.Forms.Panel Hallway6;
        private System.Windows.Forms.Panel Hallway3;
        private System.Windows.Forms.Panel Hallway7;
        private System.Windows.Forms.Panel Hallway4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel MissScarlet;
        private System.Windows.Forms.Panel ColMustard;
        private System.Windows.Forms.Panel ProfPlum;
        private System.Windows.Forms.Panel MrsPeacock;
        private System.Windows.Forms.Panel MrGreen;
        private System.Windows.Forms.Panel MrsWhite;
    }
}

