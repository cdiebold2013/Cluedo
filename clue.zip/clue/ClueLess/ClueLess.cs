﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClueLess
{
    public partial class ClueLess : Form
    {
        private enum GameState {
            STATE_START,
            STATE_HOST_GAME,
            STATE_GAME_RUNNING,
            STATE_GAME_ENDED,
        }

        public enum Character {
            MissScarlet,
            ProfPlum,
            ColMustard,
            MrsPeacock,
            MrGreen,
            MrsWhite,
        }

        public Color[] CharacterColors = new Color[] {
            Color.Red,
            Color.Purple,
            Color.Yellow,
            Color.Blue,
            Color.Green,
            Color.White,
        };

        private enum Weapon {
            Rope,
            LeadPipe,
            Knife,
            Wrench,
            Candlestick,
            Revolver,
        }

        private enum MessageID {
            MESSAGE_CHAT,
            MESSAGE_MOVE,
            MESSAGE_SUGGEST,
            MESSAGE_ACCUSE,
        }

        public class Player
        {
            public Socket socket;
            public Character character;
            public bool active;
            public BoardPos pos;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////
        private abstract class Base {

            public abstract void run();

            public abstract void startGame();

            public abstract void sendChatMessage(String text);

            private ClueLess clueless;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////
        private class Client : Base
        {
            private ClueLess clueless;
            private Socket serverSocket;

            public Client(ClueLess clueless)
            {
                this.clueless = clueless;

                serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                System.Net.IPAddress serverIP = System.Net.IPAddress.Parse(clueless.IpAddr.Text);
                int port = 100;

                var result = serverSocket.BeginConnect(serverIP, port, null, null);
                var success = result.AsyncWaitHandle.WaitOne(TimeSpan.FromSeconds(5));

                if (!success)
                {
                    throw new Exception();
                }

                clueless.ChatWindow.AppendText("Joined game!");
                clueless.ChatWindow.AppendText(Environment.NewLine);
            }

            public override void run()
            {
                readMessages();
            }

            public override void sendChatMessage(string text)
            {
                throw new NotImplementedException();
            }

            public override void startGame()
            {
                throw new NotImplementedException();
            }

            private void readMessages()
            {
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////
        private class Server : Base
        {
            private ClueLess clueless;

            private List<BoardPos> board = new List<BoardPos>();

            private List<Player> players = new List<Player>();
            private Socket serverSocket;

            private ClueLess.GameState curState = GameState.STATE_HOST_GAME;

            private Weapon murderWeapon;
            private Character murderer;

            public Server(ClueLess clueless)
            {
                this.clueless = clueless;

                serverSocket = new Socket(SocketType.Stream, ProtocolType.Tcp);
                serverSocket.Bind(new System.Net.IPEndPoint(System.Net.IPAddress.Any, 100));
                serverSocket.Listen(6);

                serverSocket.BeginAccept(addPlayer, serverSocket);

                clueless.JoinGameButton.Enabled = false;
                clueless.HostGameButton.Visible = false;
                clueless.EndGameButton.Visible = true;
                clueless.StartGameButton.Enabled = true;

                clueless.ChatWindow.AppendText("Waiting for players to join.");
                clueless.ChatWindow.AppendText(Environment.NewLine);

                Random rand = new Random();

                int num = rand.Next(0, 6);
                murderer = (Character)num;

                num = rand.Next(0, 6);
                murderWeapon = (Weapon)num;

                createBoard();
            }

            private void createBoard()
            {
                Room studyRoom = new Room(clueless.Study);
                Room hallRoom = new Room(clueless.Hall);
                Room loungeRoom = new Room(clueless.Lounge);
                Room libraryRoom = new Room(clueless.Library);
                Room billiardRoom = new Room(clueless.BilliardRoom);
                Room diningRoom = new Room(clueless.DiningRoom);
                Room conservatoryRoom = new Room(clueless.Conservatory);
                Room ballroomRoom = new Room(clueless.Ballroom);
                Room kitchenRoom = new Room(clueless.Kitchen);

                Hallway studyAndHall = new Hallway(clueless.Hallway0, studyRoom, hallRoom);
                Hallway studyAndLibrary = new Hallway(clueless.Hallway2, studyRoom, libraryRoom);
                Hallway hallAndLounge = new Hallway(clueless.Hallway1, hallRoom, loungeRoom);
                Hallway hallAndBilliard = new Hallway(clueless.Hallway3, hallRoom, billiardRoom);
                Hallway loungeAndDining = new Hallway(clueless.Hallway4, loungeRoom, diningRoom);
                Hallway libraryAndBilliard = new Hallway(clueless.Hallway10, libraryRoom, billiardRoom);
                Hallway billiardAndDining = new Hallway(clueless.Hallway11, billiardRoom, diningRoom);
                Hallway libraryAndConservatory = new Hallway(clueless.Hallway5, libraryRoom, conservatoryRoom);
                Hallway billiardAndBallroom = new Hallway(clueless.Hallway6, billiardRoom, ballroomRoom);
                Hallway diningAndKitchen = new Hallway(clueless.Hallway7, diningRoom, kitchenRoom);
                Hallway conservatoryAndBallroom = new Hallway(clueless.Hallway8, conservatoryRoom, ballroomRoom);
                Hallway ballroomAndKitchen = new Hallway(clueless.Hallway9, ballroomRoom, kitchenRoom);

                studyRoom.addHallway(studyAndHall);
                studyRoom.addHallway(studyAndLibrary);

                hallRoom.addHallway(studyAndHall);
                hallRoom.addHallway(hallAndLounge);
                hallRoom.addHallway(hallAndBilliard);

                loungeRoom.addHallway(hallAndLounge);
                loungeRoom.addHallway(loungeAndDining);

                libraryRoom.addHallway(studyAndLibrary);
                libraryRoom.addHallway(libraryAndBilliard);
                libraryRoom.addHallway(libraryAndConservatory);

                billiardRoom.addHallway(hallAndBilliard);
                billiardRoom.addHallway(libraryAndBilliard);
                billiardRoom.addHallway(billiardAndDining);
                billiardRoom.addHallway(billiardAndBallroom);

                diningRoom.addHallway(loungeAndDining);
                diningRoom.addHallway(billiardAndDining);
                diningRoom.addHallway(diningAndKitchen);

                conservatoryRoom.addHallway(libraryAndConservatory);
                conservatoryRoom.addHallway(conservatoryAndBallroom);

                ballroomRoom.addHallway(conservatoryAndBallroom);
                ballroomRoom.addHallway(billiardAndBallroom);
                ballroomRoom.addHallway(ballroomAndKitchen);

                kitchenRoom.addHallway(diningAndKitchen);
                kitchenRoom.addHallway(ballroomAndKitchen);

                board.Add(studyRoom);
                board.Add(hallRoom);
                board.Add(loungeRoom);
                board.Add(libraryRoom);
                board.Add(billiardRoom);
                board.Add(diningRoom);
                board.Add(conservatoryRoom);
                board.Add(ballroomRoom);
                board.Add(kitchenRoom);
            }

            private void addPlayer(IAsyncResult ar)
            {
                Socket server = (Socket)ar.AsyncState;
                Socket client = server.EndAccept(ar);

                if (ar.IsCompleted && (players.Count < 5)) {
                    Player p = new Player();
                    p.active = true;
                    p.character = Character.ColMustard;
                    p.socket = client;

                    players.Add(p);
                }
            }

            public override void run()
            {
                switch (curState) {
                    case GameState.STATE_HOST_GAME:
                        break;

                    case GameState.STATE_GAME_RUNNING:
                        break;
                }
            }

            public override void sendChatMessage(string text)
            {
                byte[] command = new byte[text.Length + 2];
                command[0] = (byte)ClueLess.MessageID.MESSAGE_CHAT;

                byte[] message = Encoding.ASCII.GetBytes(text);
                message.CopyTo(command, 1);

                for (int i = 0; i < players.Count(); ++i)
                {
                    players[i].socket.Send(command);
                }
            }

            public override void startGame()
            {
                clueless.ChatWindow.AppendText("Starting game.");
                clueless.ChatWindow.AppendText(Environment.NewLine);

                curState = GameState.STATE_GAME_RUNNING;

                List<BoardPos> boardpos = board;
                Random rand = new Random();
                var temp = board.OrderBy(c => rand.Next()).ToList();
                Stack<BoardPos> stack = new Stack<BoardPos>(temp);

                foreach (Player p in players) {
                    p.pos = stack.Pop();
                }
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////
        public abstract class BoardPos {
            public List<Player> players;

            public abstract void movePlayer(Player p);
        }

        public class Hallway : BoardPos
        {
            public Hallway(Panel hallway, BoardPos room1, BoardPos room2)
            {
                this.hallway = hallway;
                this.room1 = room1;
                this.room2 = room2;
            }

            public Panel hallway;
            public BoardPos room1;
            public BoardPos room2;

            public override void movePlayer(Player p)
            {
                players.Add(p);

                room1.players.Remove(p);
                room2.players.Remove(p);
            }
        }

        public class Room : BoardPos
        {
            public Panel roomPanel;
            public List<BoardPos> hallways;

            public Room(Panel room)
            {
                roomPanel = room;
                hallways = new List<BoardPos>();
            }

            public void addHallway(BoardPos hallway)
            {
                hallways.Add(hallway);
            }

            public override void movePlayer(Player p)
            {
                players.Add(p);

                foreach (BoardPos pos in hallways) {
                    pos.players.Remove(p);
                }
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////
        private Base baseGame;

        ////////////////////////////////////////////////////////////////////////////////////////////////
        public ClueLess()
        {
            InitializeComponent();

            Application.Idle += Main;
        }

        private void Main(object sender, EventArgs e)
        {
            if (baseGame != null)
                baseGame.run();
        }

        private void JoinGame_Click(object sender, EventArgs e)
        {
            try
            {
                baseGame = new Client(this);
            }
            catch (Exception)
            {
                ChatWindow.AppendText("Failed to connect to the server.");
                ChatWindow.AppendText(Environment.NewLine);
            }
        }

        private void HostGame_Click(object sender, EventArgs e)
        {
            baseGame = new Server(this);
        }

        private void StartGameButton_Click(object sender, EventArgs e)
        {
            baseGame.startGame();
        }

        private void PlayerChat_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (PlayerChat.Text.Length != 0)
                {
                    sendChatMessage(PlayerChat.Text);

                    PlayerChat.Clear();
                }
            }
        }

        private void sendChatMessage(String text)
        {
            ChatWindow.AppendText(PlayerChat.Text);
            ChatWindow.AppendText(Environment.NewLine);

            baseGame.sendChatMessage(text);
        }
    }
}
